export const items = [
  {
    id: "1",
    name: "MacBook Pro",
    category: "Portátil",
    quantity: 5,
    isCritical: true,
  },
  { id: "2", name: 'Monitor Dell 27"', category: "Monitor", quantity: 0 },
  { id: "3", name: "Teclado Mecánico", category: "Periférico", quantity: 12 },
  {id: "4", name: "Item MALO", category: " otro", quantity: 0,isCritical:true}
];
